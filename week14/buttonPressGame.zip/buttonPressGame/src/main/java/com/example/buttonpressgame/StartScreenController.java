package com.example.buttonpressgame;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class StartScreenController {

    @FXML
    private Label welcomeText;

    @FXML
    void startGame(ActionEvent event) {
        try {
            Node node = (Node) event.getSource();
            Stage stage = (Stage) node.getScene().getWindow();

            FXMLLoader fxmlLoader = new FXMLLoader(ButtonGameApp.class.getResource("game-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            stage.setTitle("Button Pressing Game!");
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            System.out.println("Error loading new scene from FXML file!");
        }
    }

}
