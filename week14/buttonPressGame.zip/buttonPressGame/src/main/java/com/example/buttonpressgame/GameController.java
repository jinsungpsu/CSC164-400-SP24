package com.example.buttonpressgame;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;

import java.io.IOException;

public class GameController {

    @FXML
    void correctAnswer(MouseEvent event) {
        ButtonGameApp.correctAnswers++;
        try {
            Node node = (Node) event.getSource();
            Stage stage = (Stage) node.getScene().getWindow();

            FXMLLoader fxmlLoader = new FXMLLoader(ButtonGameApp.class.getResource("game-over-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            stage.setTitle("Button Pressing Game!");
            stage.setScene(scene);
            stage.show();
        } catch(IOException e) {
            System.out.println("Error loading new scene from FXML file!");
        }
    }

    @FXML
    void incorrectAnswer(MouseEvent event) {
        ButtonGameApp.incorrectAnswers++;
    }

    @FXML
    void initialize() {
        ButtonGameApp.correctAnswers = 0;
        ButtonGameApp.incorrectAnswers = 0;
    }

}
