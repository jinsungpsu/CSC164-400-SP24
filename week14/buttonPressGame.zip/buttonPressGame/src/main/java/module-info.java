module com.example.buttonpressgame {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.buttonpressgame to javafx.fxml;
    exports com.example.buttonpressgame;
}