module com.example.week11lab {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.week11lab to javafx.fxml;
    exports com.example.week11lab;
}